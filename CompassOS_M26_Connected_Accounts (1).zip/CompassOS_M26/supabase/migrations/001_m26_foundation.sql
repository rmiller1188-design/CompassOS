begin;

create extension if not exists pgcrypto;

create table if not exists public.workspaces (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 80),
  kind text not null check (kind in ('personal','shared')),
  created_by uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.workspace_members (
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'member' check (role in ('owner','admin','member')),
  created_at timestamptz not null default now(),
  primary key (workspace_id,user_id)
);

create table if not exists public.profiles (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  personal_workspace_id uuid not null references public.workspaces(id) on delete cascade,
  kind text not null default 'personal' check (kind in ('personal')),
  display_name text not null,
  avatar_url text,
  settings jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(owner_id,kind)
);

create table if not exists public.provider_connections (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  profile_id uuid not null references public.profiles(id) on delete cascade,
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  provider text not null check (provider in ('google','microsoft')),
  external_account_id text not null,
  account_email text not null,
  display_name text,
  status text not null default 'healthy' check (status in ('healthy','syncing','error','reauth_required','disconnected')),
  scopes text[] not null default '{}',
  token_expires_at timestamptz,
  last_sync_at timestamptz,
  last_error text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(owner_id,provider,external_account_id)
);

create table if not exists public.provider_credentials (
  connection_id uuid primary key references public.provider_connections(id) on delete cascade,
  encrypted_payload text not null,
  iv text not null,
  auth_tag text not null,
  key_version integer not null default 1,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.sync_runs (
  id uuid primary key default gen_random_uuid(),
  connection_id uuid not null references public.provider_connections(id) on delete cascade,
  owner_id uuid not null references auth.users(id) on delete cascade,
  status text not null check (status in ('running','completed','failed')),
  item_counts jsonb not null default '{}'::jsonb,
  error_code text,
  started_at timestamptz not null default now(),
  completed_at timestamptz
);

create table if not exists public.communication_items (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  profile_id uuid references public.profiles(id) on delete set null,
  connection_id uuid references public.provider_connections(id) on delete cascade,
  provider text not null,
  external_id text not null,
  thread_external_id text,
  channel text not null check (channel in ('email','sms','call','voicemail','share','other')),
  direction text not null default 'inbound' check (direction in ('inbound','outbound','internal')),
  subject text,
  sender text,
  recipients text[] not null default '{}',
  preview text,
  body_text text,
  occurred_at timestamptz not null,
  raw_metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(provider,connection_id,external_id)
);

create table if not exists public.calendar_events (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  profile_id uuid references public.profiles(id) on delete set null,
  connection_id uuid references public.provider_connections(id) on delete cascade,
  provider text not null,
  external_id text not null,
  title text not null,
  description text,
  location text,
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  all_day boolean not null default false,
  attendees jsonb not null default '[]'::jsonb,
  raw_metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(provider,connection_id,external_id)
);

create table if not exists public.people (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  profile_id uuid references public.profiles(id) on delete set null,
  connection_id uuid references public.provider_connections(id) on delete cascade,
  provider text not null,
  external_id text not null,
  display_name text not null,
  email_addresses text[] not null default '{}',
  phone_numbers text[] not null default '{}',
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(provider,connection_id,external_id)
);

create table if not exists public.shared_tasks (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  created_by uuid not null references auth.users(id) on delete cascade,
  assigned_to uuid references auth.users(id) on delete set null,
  title text not null,
  notes text,
  status text not null default 'open' check (status in ('open','in_progress','done','cancelled')),
  due_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.file_entries (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  storage_path text not null unique,
  file_name text not null,
  content_type text not null,
  size_bytes bigint not null check (size_bytes > 0 and size_bytes <= 78643200),
  visibility text not null default 'private' check (visibility in ('private','shared')),
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.share_intake_items (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  visibility text not null check (visibility in ('private','shared')),
  item_type text not null check (item_type in ('text','url','image','video','file')),
  note text,
  source_url text,
  file_entry_id uuid references public.file_entries(id) on delete set null,
  status text not null default 'ready' check (status in ('ready','processed','failed')),
  created_at timestamptz not null default now()
);

create table if not exists public.workspace_invitations (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  invited_by uuid not null references auth.users(id) on delete cascade,
  email text not null,
  token_hash text not null unique,
  expires_at timestamptz not null,
  accepted_at timestamptz,
  accepted_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.ai_briefs (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  brief jsonb not null,
  model text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.action_requests (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  connection_id uuid references public.provider_connections(id) on delete set null,
  action_type text not null,
  risk_level text not null default 'external_write' check (risk_level in ('internal','external_write','financial')),
  payload jsonb not null,
  status text not null default 'pending' check (status in ('pending','approved','rejected','executing','completed','failed','expired')),
  approved_by uuid references auth.users(id) on delete set null,
  approved_at timestamptz,
  executed_at timestamptz,
  idempotency_key text not null unique,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists communication_items_workspace_time_idx on public.communication_items(workspace_id,occurred_at desc);
create index if not exists calendar_events_workspace_start_idx on public.calendar_events(workspace_id,starts_at);
create index if not exists people_workspace_name_idx on public.people(workspace_id,display_name);
create index if not exists provider_connections_owner_idx on public.provider_connections(owner_id,status);
create index if not exists file_entries_workspace_idx on public.file_entries(workspace_id,created_at desc);

create or replace function public.is_workspace_member(target_workspace uuid)
returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from public.workspace_members wm where wm.workspace_id=target_workspace and wm.user_id=auth.uid());
$$;

create or replace function public.is_workspace_admin(target_workspace uuid)
returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from public.workspace_members wm where wm.workspace_id=target_workspace and wm.user_id=auth.uid() and wm.role in ('owner','admin'));
$$;

create or replace function public.bootstrap_compass_user(target_user uuid, target_email text, metadata jsonb default '{}'::jsonb)
returns void language plpgsql security definer set search_path=public as $$
declare
  workspace_id uuid;
  display_name text;
begin
  if exists(select 1 from public.profiles where owner_id=target_user and kind='personal') then return; end if;
  display_name := coalesce(nullif(metadata->>'full_name',''), nullif(metadata->>'name',''), split_part(coalesce(target_email,'You'),'@',1), 'You');
  insert into public.workspaces(name,kind,created_by) values (display_name || '''s Private Space','personal',target_user) returning id into workspace_id;
  insert into public.workspace_members(workspace_id,user_id,role) values (workspace_id,target_user,'owner');
  insert into public.profiles(owner_id,personal_workspace_id,kind,display_name) values (target_user,workspace_id,'personal',display_name);
end;
$$;

create or replace function public.handle_new_auth_user()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  perform public.bootstrap_compass_user(new.id,new.email,new.raw_user_meta_data);
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_auth_user();

do $$ declare r record; begin
  for r in select id,email,raw_user_meta_data from auth.users loop
    perform public.bootstrap_compass_user(r.id,r.email,r.raw_user_meta_data);
  end loop;
end $$;

alter table public.workspaces enable row level security;
alter table public.workspace_members enable row level security;
alter table public.profiles enable row level security;
alter table public.provider_connections enable row level security;
alter table public.provider_credentials enable row level security;
alter table public.sync_runs enable row level security;
alter table public.communication_items enable row level security;
alter table public.calendar_events enable row level security;
alter table public.people enable row level security;
alter table public.shared_tasks enable row level security;
alter table public.file_entries enable row level security;
alter table public.share_intake_items enable row level security;
alter table public.workspace_invitations enable row level security;
alter table public.ai_briefs enable row level security;
alter table public.action_requests enable row level security;

create policy workspaces_member_select on public.workspaces for select to authenticated using (public.is_workspace_member(id));
create policy workspaces_creator_insert on public.workspaces for insert to authenticated with check (created_by=auth.uid());
create policy workspaces_admin_update on public.workspaces for update to authenticated using (public.is_workspace_admin(id)) with check (public.is_workspace_admin(id));

create policy members_member_select on public.workspace_members for select to authenticated using (public.is_workspace_member(workspace_id));
create policy members_admin_insert on public.workspace_members for insert to authenticated with check (public.is_workspace_admin(workspace_id) or user_id=auth.uid());
create policy members_admin_update on public.workspace_members for update to authenticated using (public.is_workspace_admin(workspace_id));
create policy members_admin_delete on public.workspace_members for delete to authenticated using (public.is_workspace_admin(workspace_id) or user_id=auth.uid());

create policy profiles_owner_select on public.profiles for select to authenticated using (owner_id=auth.uid());
create policy profiles_owner_update on public.profiles for update to authenticated using (owner_id=auth.uid()) with check (owner_id=auth.uid());

create policy connections_owner_all on public.provider_connections for all to authenticated using (owner_id=auth.uid()) with check (owner_id=auth.uid());
create policy sync_runs_owner_select on public.sync_runs for select to authenticated using (owner_id=auth.uid());

create policy communications_member_select on public.communication_items for select to authenticated using (public.is_workspace_member(workspace_id));
create policy communications_owner_insert on public.communication_items for insert to authenticated with check (owner_id=auth.uid() and public.is_workspace_member(workspace_id));
create policy communications_owner_update on public.communication_items for update to authenticated using (owner_id=auth.uid());
create policy communications_owner_delete on public.communication_items for delete to authenticated using (owner_id=auth.uid());

create policy events_member_select on public.calendar_events for select to authenticated using (public.is_workspace_member(workspace_id));
create policy events_owner_insert on public.calendar_events for insert to authenticated with check (owner_id=auth.uid() and public.is_workspace_member(workspace_id));
create policy events_owner_update on public.calendar_events for update to authenticated using (owner_id=auth.uid());
create policy events_owner_delete on public.calendar_events for delete to authenticated using (owner_id=auth.uid());

create policy people_member_select on public.people for select to authenticated using (public.is_workspace_member(workspace_id));
create policy people_owner_all on public.people for all to authenticated using (owner_id=auth.uid()) with check (owner_id=auth.uid() and public.is_workspace_member(workspace_id));

create policy tasks_member_select on public.shared_tasks for select to authenticated using (public.is_workspace_member(workspace_id));
create policy tasks_member_insert on public.shared_tasks for insert to authenticated with check (created_by=auth.uid() and public.is_workspace_member(workspace_id));
create policy tasks_member_update on public.shared_tasks for update to authenticated using (public.is_workspace_member(workspace_id));
create policy tasks_member_delete on public.shared_tasks for delete to authenticated using (created_by=auth.uid() or public.is_workspace_admin(workspace_id));

create policy files_member_select on public.file_entries for select to authenticated using (public.is_workspace_member(workspace_id));
create policy files_owner_insert on public.file_entries for insert to authenticated with check (owner_id=auth.uid() and public.is_workspace_member(workspace_id));
create policy files_owner_update on public.file_entries for update to authenticated using (owner_id=auth.uid());
create policy files_owner_delete on public.file_entries for delete to authenticated using (owner_id=auth.uid());

create policy intake_member_select on public.share_intake_items for select to authenticated using (public.is_workspace_member(workspace_id));
create policy intake_owner_insert on public.share_intake_items for insert to authenticated with check (owner_id=auth.uid() and public.is_workspace_member(workspace_id));
create policy intake_owner_update on public.share_intake_items for update to authenticated using (owner_id=auth.uid());
create policy intake_owner_delete on public.share_intake_items for delete to authenticated using (owner_id=auth.uid());

create policy invitations_admin_select on public.workspace_invitations for select to authenticated using (public.is_workspace_admin(workspace_id));
create policy invitations_admin_insert on public.workspace_invitations for insert to authenticated with check (invited_by=auth.uid() and public.is_workspace_admin(workspace_id));
create policy invitations_admin_update on public.workspace_invitations for update to authenticated using (public.is_workspace_admin(workspace_id));
create policy invitations_admin_delete on public.workspace_invitations for delete to authenticated using (public.is_workspace_admin(workspace_id));

create policy briefs_member_select on public.ai_briefs for select to authenticated using (public.is_workspace_member(workspace_id));
create policy briefs_owner_insert on public.ai_briefs for insert to authenticated with check (owner_id=auth.uid() and public.is_workspace_member(workspace_id));

create policy actions_member_select on public.action_requests for select to authenticated using (public.is_workspace_member(workspace_id));
create policy actions_owner_insert on public.action_requests for insert to authenticated with check (owner_id=auth.uid() and public.is_workspace_member(workspace_id));
create policy actions_approver_update on public.action_requests for update to authenticated using (public.is_workspace_member(workspace_id));

revoke all on public.provider_credentials from anon, authenticated;
revoke all on public.sync_runs from anon;

grant usage on schema public to authenticated;
grant select,insert,update,delete on all tables in schema public to authenticated;
revoke all on public.provider_credentials from authenticated;

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values ('compass-files','compass-files',false,78643200,null)
on conflict (id) do update set public=false,file_size_limit=excluded.file_size_limit;

create policy compass_storage_select on storage.objects for select to authenticated using (
  bucket_id='compass-files' and public.is_workspace_member(((storage.foldername(name))[1])::uuid)
);
create policy compass_storage_insert on storage.objects for insert to authenticated with check (
  bucket_id='compass-files'
  and public.is_workspace_member(((storage.foldername(name))[1])::uuid)
  and ((storage.foldername(name))[2])::uuid=auth.uid()
);
create policy compass_storage_update on storage.objects for update to authenticated using (
  bucket_id='compass-files' and owner_id::uuid=auth.uid()
) with check (
  bucket_id='compass-files' and owner_id::uuid=auth.uid()
);
create policy compass_storage_delete on storage.objects for delete to authenticated using (
  bucket_id='compass-files' and owner_id::uuid=auth.uid()
);

commit;
